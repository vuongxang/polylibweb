CKEDITOR.plugins.setLang( 'pre', 'ru', {
  title : 'Заголовок',
  content : 'Введите текст или фрагмент кода...',
	dialogTitle: 'Пареметры фрагмента кода',
	button: 'Вставить фрагмент кода',
  color : 'Цвет фона',
  colorDefault : 'По умолчанию',
  colorGray : 'Серый',
  colorBlack : 'Черный',
  maxheight : 'Макс. высота',
  maxheightDefault : 'Не ограничена',
	hidesummary: 'Скрыть заголовок',
	collapse: 'Свернуть',
	monospace: 'Моноширинный шрифт',
	wrap: 'Автоперенос строк',
	bordered: 'Обводка',
	cssclass: 'CSS-классы'
});