CKEDITOR.plugins.setLang( 'pre', 'en', {
  title : 'Title',
  content : 'Enter text or code snippet...',
	dialogTitle: 'Collapsible snippet settings',
	button: 'Insert collapsible snippet',
  color : 'Background',
  colorDefault : 'Default',
  colorGray : 'Gray',
  colorBlack : 'Black',
  maxheight : 'Max height',
  maxheightDefault : 'Unconstrained',
	hidesummary: 'Hide title',
	collapse: 'Collapsed',
	monospace: 'Monospace font',
	wrap: 'Autowrap long lines',
	bordered: 'Bordered',
	cssclass: 'CSS classes'
});

